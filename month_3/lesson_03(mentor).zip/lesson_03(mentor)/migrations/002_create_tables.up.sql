ALTER TABLE "staffs"
ADD COLUMN "username" varchar,
ADD COLUMN "password" varchar;