DROP TABLE IF EXISTS "transactions";

DROP TABLE IF EXISTS "sales";

DROP TABLE IF EXISTS "staffs";

DROP TABLE IF EXISTS "tariffs";

DROP TABLE IF EXISTS "branches";

DROP TYPE IF EXISTS "source_type";

DROP TYPE IF EXISTS "transaction_type";

DROP TYPE IF EXISTS "status_type";

DROP TYPE IF EXISTS "payment_type";

DROP TYPE IF EXISTS "tariff_type";

DROP TYPE IF EXISTS "staff_type";


